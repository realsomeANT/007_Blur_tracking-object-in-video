import { useState } from "react";

const defaultApiBase = "http://localhost:8000";

function App() {
  const [apiBase, setApiBase] = useState(defaultApiBase);
  const [effect, setEffect] = useState("blur");
  const [matchThreshold, setMatchThreshold] = useState(0.9);
  const [blurKernel, setBlurKernel] = useState(81);
  const [jumpFactor, setJumpFactor] = useState(0.25);
  const [fourcc, setFourcc] = useState("mp4v");
  const [resultUrl, setResultUrl] = useState(null);
  const [isSubmitting, setIsSubmitting] = useState(false);
  const [error, setError] = useState(null);
  const [successMessage, setSuccessMessage] = useState(null);

  const handleSubmit = async (event) => {
    event.preventDefault();
    setError(null);
    setSuccessMessage(null);
    setResultUrl(null);

    const form = event.target;
    const videoFile = form.video.files[0];
    const templateFiles = Array.from(form.templates.files);
    if (!videoFile) {
      setError("กรุณาอัปโหลดไฟล์วิดีโอ");
      return;
    }
    if (!templateFiles.length) {
      setError("กรุณาอัปโหลด template อย่างน้อย 1 ไฟล์");
      return;
    }

    const payload = new FormData();
    payload.append("video", videoFile);
    templateFiles.forEach((file) => payload.append("templates", file));
    if (form.overlay.files[0]) {
      payload.append("overlay_image", form.overlay.files[0]);
    }
    payload.append("effect", effect);
    payload.append("match_threshold", matchThreshold);
    payload.append("blur_kernel", blurKernel);
    payload.append("jump_factor", jumpFactor);
    payload.append("fourcc", fourcc);

    setIsSubmitting(true);
    try {
      const response = await fetch(`${apiBase}/process`, {
        method: "POST",
        body: payload,
      });

      if (!response.ok) {
        const text = await response.text();
        throw new Error(text || "ไม่สามารถประมวลผลได้");
      }

      const blob = await response.blob();
      const url = URL.createObjectURL(blob);
      setResultUrl(url);
      setSuccessMessage("ประมวลผลสำเร็จ สามารถดาวน์โหลดไฟล์ได้ด้านล่าง");
    } catch (err) {
      setError(err.message || "เกิดข้อผิดพลาดไม่ทราบสาเหตุ");
    } finally {
      setIsSubmitting(false);
    }
  };

  return (
    <div className="app">
      <header>
        <h1>Video Blur/Overlay</h1>
        <p>อัปโหลดวิดีโอและภาพวัตถุที่ต้องการ Blur (template image) เพื่อเบลอหรือวางภาพทับผ่าน API</p>
        <div className="card1" style={{ textAlign: 'left', marginBottom: '2rem' }}>
          <p>คำอธิบาย คือ เป็นโปรแกรมที่จะ blur วัตถุที่มันทำการ tracking ในวิดีโอ <br />
            ประโยชน์ของโปรแกรม คือ ใช้ blur วัตถุที่ไม่ต้องการในวิดีโอ อาทิ ใบหน้าคน ป้ายทะเบียนรถ ใช้ป้องกันการโดน PDPA
          </p>
          <p>หลักการทำงานของโปรแกรม</p>
          <ol style={{ marginTop:'-01rem'}}>  
            <li>ใส่วิดีโอที่ต้องการให้โปรแกรมเบลอลงไป </li>
            <li>ใส่ภาพวัตถุที่ต้องการให้มันเบลอลงไปใน (template image) โดยสามารถใส่ได้หลายภาพพร้อมกัน
              <ul>
                <li>โดยต้องตั้งชื่อภาพเป็นเวลาเริ่มต้นในการให้โปรแกรมเริ่มใช้ภาพนั้นไปทำ template matching เช่น 0m00s คือให้โปรแกรมเริ่มใช้ภาพนี้ไปทำ template matching ตั้งแต่เวลา 0 นาที 00 วินาที คือทำงานตั้งแต่เริ่มทำงานของวิดีโอ</li>
              </ul>
            </li>
            <li>จากนั้นโปรแกรมจะเอาภาพเหล่านั้นไปเทียบเพื่อหาพื้นที่ที่ต้องการติดตามโดยพื้นนั้นที่ทำการติดตาม ต้องตรงหรือมีความเหมือนกับภาพที่นำมาเทียบถึง 90% เมื่อเจอแล้วจะหยุดใช้ภาพนั้นในการนำไปเทียบหาพื้นที่
              <ul>
                <li>แต่ถ้ายังหาพื้นที่ไม่เจอก็จะใช้ภาพนั้นเทียบไปเรื่อย ๆ จนกว่าจะได้พื้นที่ ๆ ต้องการ</li>
              </ul>
            </li>
            <li>โปรแกรมก็จะเบลอหรือเอาภาพอื่นมาทับ (แล้วแต่จะเลือก) ลงบนพื้นที่ที่ติดตามตาม จนกว่าพื้นที่ที่ติดหลุดออกจากเฟรมกล้องเกิน 40%
              <ul>
                <li>หรือพื้นที่ที่ติดตามมีการขยับเปลี่ยนตำแหน่งอย่างรวดเร็วและระยะกว้างกว่าปกติเกิน 25% (กรณีที่การติดตามหลุดจากหลายปัจจัย อาทิ วัตถุที่ติดตามโดนบังโดยวัตถุอื่น)</li>
              </ul>
            </li>
          </ol>
        </div>
      </header>

      <form className="card" onSubmit={handleSubmit}>
        <label>
          API Base URL
          <input
            type="text"
            value={apiBase}
            onChange={(event) => setApiBase(event.target.value)}
            placeholder="http://localhost:8000"
            disabled
          />
        </label>

        <label>
          วิดีโอ (mp4, mov, ฯลฯ)
          <input name="video" type="file" accept="video/*" required />
        </label>

        <label>
          ภาพวัตถุที่ต้องการ Blur (template image ใส่ได้หลายไฟล์พร้อมกัน)
          <input name="templates" type="file" accept="image/*" multiple required />
          <div class="small">
            ใช้ชื่อไฟล์รูปให้ระบุเวลาที่ต้องเริ่ม matching เช่น <code>0m05s.png</code>,
            <code>1m20s.jpg</code> หรือ <code>2h01m10s.bmp</code> (นาที m, วินาที s, ชั่วโมง h)
          </div>
        </label>
        
        <label>
          ภาพที่ต้องการเอาทับ (Overlay Image ทำงานได้เฉพาะโหมด overlay)
          <input name="overlay" type="file" accept="image/*" disabled={effect !== "overlay"} />
        </label>

        <label>
          โหมดการทำงาน
          <select value={effect} onChange={(event) => setEffect(event.target.value)}>
            <option value="blur">โหมด Blur</option>
            <option value="overlay">โหมดภาพทับ</option>
          </select>
        </label>

        <div className="grid">
          <label>
            Match Threshold
            <input
              type="number"
              step="0.01"
              min="0"
              max="1"
              value={matchThreshold}
              onChange={(event) => setMatchThreshold(event.target.value)}
            />
            <div class="small" >ความเหมือนกับภาพวัตถุที่ต้องการ blur <br />(ยิ่งค่าเข้าใกล้ 1 มาก ยิ่งทำงานได้แม่นยำ)</div>
          </label>
          <label>
             Blur Kernel
            <input
              type="number"
              min="3"
              step="2"
              value={blurKernel}
              onChange={(event) => setBlurKernel(event.target.value)}
            />
            <div class="small">ความเข้มของการเบลอ <br />(Blur Kernel ต้องเป็นเลขคี่และมากกว่า 1)</div>
          </label>
          <label>
            Jump Factor
            <input
              type="number"
              step="0.05"
              min="0.05"
              value={jumpFactor}
              onChange={(event) => setJumpFactor(event.target.value)}
            />
            <div class="small">ความเข้มงวดในการตรวจจับการเคลื่อนไหวที่ผิดปกติ <br />(Jump Factor ยิ่งค่าเข้าใกล้ 1 ยิ่งเข้มงวดในการตรวจจับ)</div>
          </label>
          <label>
            FourCC
            <input
              type="text"
              maxLength={4}
              value={fourcc}
              onChange={(event) => setFourcc(event.target.value)}
            />
            <div class="small">ประเภทไฟล์วิดีโอผลลัพธ์ <br />(FourCC เช่น mp4v, avc1, ฯลฯ)</div>
          </label>
        </div>

        <button type="submit" disabled={isSubmitting}>
          {isSubmitting ? "กำลังประมวลผล..." : "ประมวลผลวิดีโอ"}
        </button>
      </form>

      {error && <p className="status error">{error}</p>}
      {successMessage && <p className="status success">{successMessage}</p>}

      {resultUrl && (
        <div className="card">
          <h2>ผลลัพธ์</h2>
          <a className="download" href={resultUrl} download="processed-video.mp4">
            ดาวน์โหลดไฟล์
          </a>
        </div>
      )}
    </div>
  );
}

export default App;
