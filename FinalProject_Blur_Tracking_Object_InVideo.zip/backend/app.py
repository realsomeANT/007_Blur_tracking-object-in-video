"""FastAPI wrapper for the auto_blur processing pipeline."""
from __future__ import annotations

import shutil
import tempfile
import uuid
from pathlib import Path
from typing import List, Optional

import cv2
import numpy as np
from fastapi import (
    BackgroundTasks,
    FastAPI,
    File,
    Form,
    HTTPException,
    UploadFile,
)
from fastapi.concurrency import run_in_threadpool
from fastapi.middleware.cors import CORSMiddleware
from fastapi.responses import FileResponse, JSONResponse

try:
    from .auto_blur import process_video
except ImportError:
    from auto_blur import process_video

app = FastAPI(
    title="Video Blur Service",
    description="REST API สำหรับเบลอหรือ overlay วัตถุในวิดีโอ",
    version="0.1.0",
)

app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

OUTPUT_DIR = Path("backend/outputs")
OUTPUT_DIR.mkdir(parents=True, exist_ok=True)


async def _write_upload_to_path(upload: UploadFile, destination: Path) -> None:
    destination.parent.mkdir(parents=True, exist_ok=True)
    with destination.open("wb") as buffer:
        while True:
            chunk = await upload.read(1 << 20)
            if not chunk:
                break
            buffer.write(chunk)
    await upload.seek(0)


@app.get("/health")
async def health_check() -> JSONResponse:
    return JSONResponse({"status": "ok"})


@app.post("/process")
async def process_endpoint(
    background_tasks: BackgroundTasks,
    video: UploadFile = File(...),
    templates: List[UploadFile] = File(...),
    overlay_image: Optional[UploadFile] = File(None),
    match_threshold: float = Form(0.9),
    blur_kernel: int = Form(81),
    fourcc: str = Form("mp4v"),
    jump_factor: float = Form(0.25),
    effect: str = Form("blur"),
) -> FileResponse:
    if not templates:
        raise HTTPException(status_code=400, detail="กรุณาอัปโหลด template อย่างน้อย 1 ไฟล์")

    effect = effect.lower()
    if effect not in {"blur", "overlay"}:
        raise HTTPException(status_code=400, detail="effect ต้องเป็น blur หรือ overlay")

    fourcc = (fourcc or "mp4v").ljust(4, " ")[:4]

    task_dir = Path(tempfile.mkdtemp(prefix="blur-task-"))
    templates_dir = task_dir / "templates"
    templates_dir.mkdir(parents=True, exist_ok=True)

    try:
        video_path = task_dir / (video.filename or "input.mp4")
        await _write_upload_to_path(video, video_path)

        for template in templates:
            name = template.filename or f"template-{uuid.uuid4().hex}.png"
            target_path = templates_dir / Path(name).name
            await _write_upload_to_path(template, target_path)

        overlay_frame = None
        if effect == "overlay" and overlay_image is not None:
            overlay_bytes = await overlay_image.read()
            if not overlay_bytes:
                raise HTTPException(status_code=400, detail="overlay image ว่าง")
            overlay_array = np.frombuffer(overlay_bytes, dtype=np.uint8)
            overlay_frame = cv2.imdecode(overlay_array, cv2.IMREAD_COLOR)
            if overlay_frame is None:
                raise HTTPException(status_code=400, detail="ไม่สามารถอ่าน overlay image ได้")

        output_suffix = Path(video_path).suffix or ".mp4"
        # Save output to the temporary task directory instead of OUTPUT_DIR
        output_path = task_dir / f"output-{uuid.uuid4().hex}{output_suffix}"

        await run_in_threadpool(
            process_video,
            video_path,
            templates_dir,
            output_path,
            match_threshold,
            blur_kernel,
            fourcc,
            jump_factor,
            effect,
            overlay_frame,
        )

        # Schedule the temporary directory to be deleted after the response is sent
        background_tasks.add_task(shutil.rmtree, task_dir, ignore_errors=True)

        return FileResponse(
            path=output_path,
            media_type="video/mp4",
            filename=output_path.name,
        )
    except Exception:
        # If an error occurs, clean up immediately
        shutil.rmtree(task_dir, ignore_errors=True)
        raise