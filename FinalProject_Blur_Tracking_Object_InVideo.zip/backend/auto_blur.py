"""Blur or overlay selected objects in a video using template matching and CSRT tracking.

The script expects template images whose filenames encode the moment the
template should become active (e.g. "0m15s.png" starts matching at 15s).
Once a template matches a frame, a CSRT tracker keeps blurring that region
until tracking fails or most of the bounding box leaves the frame.
"""

from __future__ import annotations

import argparse
import math
import re
import sys
from dataclasses import dataclass, field
from pathlib import Path
from typing import List, Optional, Sequence, Tuple

import cv2
import numpy as np


@dataclass
class TemplateTask:
	path: Path
	start_time: float
	template_bgr: np.ndarray
	template_gray: np.ndarray
	width: int
	height: int
	status: str = field(default="pending")
	tracker: Optional[cv2.Tracker] = field(default=None, repr=False)
	last_bbox: Optional[Tuple[float, float, float, float]] = field(default=None)


SUPPORTED_IMAGE_EXT = {".png", ".jpg", ".jpeg", ".bmp", ".tif", ".tiff"}


def parse_timestamp_from_name(name: str) -> Optional[float]:
	matches = re.findall(r"(\d+)([hms])", name.lower())
	if not matches:
		return None

	total_seconds = 0.0
	for value, unit in matches:
		number = float(value)
		if unit == "h":
			total_seconds += number * 3600.0
		elif unit == "m":
			total_seconds += number * 60.0
		elif unit == "s":
			total_seconds += number
	return total_seconds


def discover_template_tasks(template_dir: Path) -> List[TemplateTask]:
	tasks: List[TemplateTask] = []
	for path in sorted(template_dir.iterdir()):
		if path.suffix.lower() not in SUPPORTED_IMAGE_EXT:
			continue

		timestamp = parse_timestamp_from_name(path.stem)
		if timestamp is None:
			print(f"[WARN] ข้ามไฟล์ {path.name} เพราะไม่สามารถอ่านเวลาได้", file=sys.stderr)
			continue

		image = cv2.imread(str(path))
		if image is None:
			print(f"[WARN] ข้ามไฟล์ {path.name} เพราะโหลดรูปไม่ได้", file=sys.stderr)
			continue

		height, width = image.shape[:2]
		if width == 0 or height == 0:
			print(f"[WARN] ข้ามไฟล์ {path.name} เพราะขนาดรูปไม่ถูกต้อง", file=sys.stderr)
			continue

		template_gray = cv2.cvtColor(image, cv2.COLOR_BGR2GRAY)
		tasks.append(
			TemplateTask(
				path=path,
				start_time=timestamp,
				template_bgr=image,
				template_gray=template_gray,
				width=width,
				height=height,
			)
		)

	tasks.sort(key=lambda task: task.start_time)
	return tasks


def create_csrt_tracker() -> cv2.Tracker:
	if hasattr(cv2, "TrackerCSRT_create"):
		return cv2.TrackerCSRT_create()
	if hasattr(cv2, "legacy") and hasattr(cv2.legacy, "TrackerCSRT_create"):
		return cv2.legacy.TrackerCSRT_create()
	raise RuntimeError("ไม่พบ CSRT tracker โปรดติดตั้ง opencv-contrib-python")


def ensure_output_path(video_path: Path, requested: Optional[str]) -> Path:
	if requested:
		out_path = Path(requested)
	else:
		out_path = video_path.with_name(f"{video_path.stem}_blurred{video_path.suffix}")
	out_path.parent.mkdir(parents=True, exist_ok=True)
	return out_path


def adjust_kernel_size(value: int) -> int:
	value = max(3, value)
	return value if value % 2 == 1 else value + 1


def bbox_visibility_ratio(bbox: Tuple[float, float, float, float], frame_w: int, frame_h: int) -> float:
	x, y, w, h = bbox
	if w <= 0 or h <= 0:
		return 0.0
	x2, y2 = x + w, y + h
	vis_x1 = max(0.0, x)
	vis_y1 = max(0.0, y)
	vis_x2 = min(float(frame_w), x2)
	vis_y2 = min(float(frame_h), y2)
	vis_w = max(0.0, vis_x2 - vis_x1)
	vis_h = max(0.0, vis_y2 - vis_y1)
	visible_area = vis_w * vis_h
	total_area = w * h
	return visible_area / total_area if total_area > 0 else 0.0


def _roi_bounds(frame_shape: Tuple[int, int, int], bbox: Tuple[float, float, float, float]) -> Optional[Tuple[int, int, int, int]]:
	frame_h, frame_w = frame_shape[:2]
	x, y, w, h = bbox
	x1 = max(0, int(round(x)))
	y1 = max(0, int(round(y)))
	x2 = min(frame_w, int(round(x + w)))
	y2 = min(frame_h, int(round(y + h)))
	if x2 <= x1 or y2 <= y1:
		return None
	return x1, y1, x2, y2


def blur_roi(frame: np.ndarray, bbox: Tuple[float, float, float, float], kernel_size: int) -> None:
	bounds = _roi_bounds(frame.shape, bbox)
	if bounds is None:
		return
	x1, y1, x2, y2 = bounds
	roi = frame[y1:y2, x1:x2]
	if roi.size == 0:
		return
	blurred = cv2.GaussianBlur(roi, (kernel_size, kernel_size), 0)
	frame[y1:y2, x1:x2] = blurred


def overlay_roi(frame: np.ndarray, bbox: Tuple[float, float, float, float], overlay_image: Optional[np.ndarray]) -> None:
	if overlay_image is None:
		return
	bounds = _roi_bounds(frame.shape, bbox)
	if bounds is None:
		return
	x1, y1, x2, y2 = bounds
	roi_w = x2 - x1
	roi_h = y2 - y1
	if roi_w <= 0 or roi_h <= 0:
		return
	resized = cv2.resize(overlay_image, (roi_w, roi_h), interpolation=cv2.INTER_LINEAR)
	frame[y1:y2, x1:x2] = resized


def is_abrupt_jump(
	prev_bbox: Tuple[float, float, float, float],
	new_bbox: Tuple[float, float, float, float],
	jump_factor: float,
) -> bool:
	px, py, pw, ph = prev_bbox
	nx, ny, nw, nh = new_bbox
	prev_center = (px + pw / 2.0, py + ph / 2.0)
	new_center = (nx + nw / 2.0, ny + nh / 2.0)
	dist = math.hypot(new_center[0] - prev_center[0], new_center[1] - prev_center[1])
	diag = math.hypot(pw, ph)
	threshold = max(diag * jump_factor, 1.0)
	return dist > threshold


def process_video(
	video_path: Path,
	template_dir: Path,
	output_path: Path,
	match_threshold: float,
	blur_kernel: int,
	fourcc: str,
	jump_factor: float,
 	effect_mode: str,
	overlay_image: Optional[np.ndarray],
) -> None:
	tasks = discover_template_tasks(template_dir)
	if not tasks:
		raise SystemExit("ไม่พบ template ใดๆ ที่ใช้งานได้")

	cap = cv2.VideoCapture(str(video_path))
	if not cap.isOpened():
		raise SystemExit(f"ไม่สามารถเปิดไฟล์วิดีโอ {video_path}")

	frame_w = int(cap.get(cv2.CAP_PROP_FRAME_WIDTH))
	frame_h = int(cap.get(cv2.CAP_PROP_FRAME_HEIGHT))
	fps = cap.get(cv2.CAP_PROP_FPS) or 0.0
	if fps <= 0:
		fps = 30.0

	blur_kernel = adjust_kernel_size(blur_kernel)
	fourcc_code = cv2.VideoWriter_fourcc(*fourcc)
	writer = cv2.VideoWriter(str(output_path), fourcc_code, fps, (frame_w, frame_h))
	if not writer.isOpened():
		cap.release()
		raise SystemExit(f"ไม่สามารถสร้างไฟล์เอาต์พุต {output_path}")

	print(f"[INFO] เริ่มประมวลผลวิดีโอ {video_path}")
	print(f"[INFO] จะบันทึกผลลัพธ์ที่ {output_path}")

	frame_idx = 0
	try:
		while True:
			ok, frame = cap.read()
			if not ok:
				break

			current_time = frame_idx / fps if fps else 0.0
			frame_gray = None

			for task in tasks:
				if task.status == "pending" and current_time >= task.start_time:
					task.status = "matching"
					print(f"[INFO] เริ่ม matching สำหรับ {task.path.name} ที่ {task.start_time:.2f}s")

				if task.status == "matching":
					if frame_gray is None:
						frame_gray = cv2.cvtColor(frame, cv2.COLOR_BGR2GRAY)
					if frame.shape[0] < task.height or frame.shape[1] < task.width:
						print(f"[WARN] ขนาดเฟรมเล็กกว่า template {task.path.name}")
						task.status = "done"
						continue

					result = cv2.matchTemplate(frame_gray, task.template_gray, cv2.TM_CCOEFF_NORMED)
					_, max_val, _, max_loc = cv2.minMaxLoc(result)
					if max_val >= match_threshold:
						bbox_int = (
							int(max_loc[0]),
							int(max_loc[1]),
							int(task.width),
							int(task.height),
						)
						try:
							tracker = create_csrt_tracker()
						except RuntimeError as exc:
							cap.release()
							writer.release()
							raise SystemExit(str(exc))
						tracker.init(frame, bbox_int)
						task.tracker = tracker
						task.status = "tracking"
						task.last_bbox = tuple(float(v) for v in bbox_int)
						print(f"[INFO] พบ {task.path.name} (score={max_val:.3f}) เริ่ม tracking")

				if task.status == "tracking" and task.tracker is not None:
					success, bbox = task.tracker.update(frame)
					if not success:
						print(f"[INFO] Tracker สำหรับ {task.path.name} สูญหาย หยุดกำกับ")
						task.status = "done"
						task.tracker = None
						continue

					if task.last_bbox is not None and is_abrupt_jump(task.last_bbox, bbox, jump_factor):
						print(f"[INFO] วัตถุ {task.path.name} ขยับผิดปกติ หยุดกำกับ")
						task.status = "done"
						task.tracker = None
						continue

					visibility = bbox_visibility_ratio(bbox, frame_w, frame_h)
					if visibility < 0.40:
						print(f"[INFO] วัตถุ {task.path.name} หลุดเฟรมเกิน 75% หยุดกำกับ")
						task.status = "done"
						task.tracker = None
						continue

					if effect_mode == "overlay":
						source = overlay_image if overlay_image is not None else task.template_bgr
						overlay_roi(frame, bbox, source)
					else:
						blur_roi(frame, bbox, blur_kernel)
					task.last_bbox = bbox

			writer.write(frame)
			frame_idx += 1
	finally:
		cap.release()
		writer.release()

	print("[INFO] ประมวลผลเสร็จสิ้น")


def parse_args(argv: Optional[Sequence[str]] = None) -> argparse.Namespace:
	parser = argparse.ArgumentParser(description="Blur objects in a video using template-based tracking")
	parser.add_argument("--video", required=True, help="พาธไปยังไฟล์วิดีโอที่ต้องการเบลอ")
	parser.add_argument("--templates", required=True, help="โฟลเดอร์ที่เก็บ template image")
	parser.add_argument("--output", help="พาธไฟล์วิดีโอผลลัพธ์ (ไม่ระบุจะใช้ *_blurred.mp4)")
	parser.add_argument("--match-threshold", type=float, default=0.90, help="ค่า threshold สำหรับ template matching (0-1)")
	parser.add_argument("--blur-kernel", type=int, default=80, help="ขนาด kernel (พิกเซล) สำหรับ Gaussian blur")
	parser.add_argument("--fourcc", default="mp4v", help="โค้ด FourCC สำหรับบันทึกไฟล์วิดีโอ (เช่น mp4v, XVID)")
	parser.add_argument(
		"--jump-factor",
		type=float,
		default=0.25,
		help="คูณกับเส้นทแยงมุม bbox เพื่อพิจารณาการขยับผิดปกติ (ค่าต่ำหยุดง่ายขึ้น)",
	)
	parser.add_argument(
		"--effect",
		choices=["blur", "overlay"],
		default="blur",
		help="เลือกว่าจะใช้การ blur หรือ overlay ภาพ",
	)
	parser.add_argument(
		"--overlay-image",
		help="หากเลือก overlay สามารถระบุไฟล์ภาพที่จะใช้ทับ (ไม่ระบุจะใช้ template นั้นๆ)",
	)
	return parser.parse_args(argv)


def main(argv: Optional[Sequence[str]] = None) -> None:
	args = parse_args(argv)
	video_path = Path(args.video)
	template_dir = Path(args.templates)
	if not video_path.exists():
		raise SystemExit(f"ไม่พบไฟล์วิดีโอ {video_path}")
	if not template_dir.is_dir():
		raise SystemExit(f"ไม่พบโฟลเดอร์ template {template_dir}")

	output_path = ensure_output_path(video_path, args.output)
	overlay_image = None
	if args.effect == "overlay" and args.overlay_image:
		overlay_path = Path(args.overlay_image)
		if not overlay_path.exists():
			raise SystemExit(f"ไม่พบไฟล์ overlay {overlay_path}")
		overlay_image = cv2.imread(str(overlay_path))
		if overlay_image is None:
			raise SystemExit(f"โหลด overlay image จาก {overlay_path} ไม่สำเร็จ")
	process_video(
		video_path=video_path,
		template_dir=template_dir,
		output_path=output_path,
		match_threshold=args.match_threshold,
		blur_kernel=args.blur_kernel,
		fourcc=args.fourcc,
		jump_factor=args.jump_factor,
		effect_mode=args.effect,
		overlay_image=overlay_image,
	)


if __name__ == "__main__":
	main()
